@echo off
title MovieBox Plus - Cinema 4K Streaming
echo Starting MovieBox Plus...
start msedge.exe --app=https://netmirror-plus.vercel.app/?source=desktop-win 2>nul || start chrome.exe --app=https://netmirror-plus.vercel.app/?source=desktop-win 2>nul || start https://netmirror-plus.vercel.app/?source=desktop-win
