#!/usr/bin/env bash
if command -v google-chrome &> /dev/null; then
    google-chrome --app=https://moviehub.stream/?source=desktop-linux &
elif command -v chromium &> /dev/null; then
    chromium --app=https://moviehub.stream/?source=desktop-linux &
elif command -v brave-browser &> /dev/null; then
    brave-browser --app=https://moviehub.stream/?source=desktop-linux &
else
    xdg-open https://moviehub.stream/?source=desktop-linux &
fi
