moviehub.stream for Windows
===========================
1. Double-click "Launch-moviehub.stream.bat" to start streaming in standalone cinema window.
2. Double-click "Create-Desktop-Shortcut.vbs" to pin moviehub.stream directly to your Windows Desktop.
