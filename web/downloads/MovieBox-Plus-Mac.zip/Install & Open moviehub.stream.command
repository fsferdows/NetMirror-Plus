#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
echo "=============================================="
echo " Installing moviehub.stream to /Applications..."
echo "=============================================="
cp -R "$DIR/MovieBox Plus.app" /Applications/
xattr -cr "/Applications/MovieBox Plus.app"
codesign --force --deep --sign - "/Applications/MovieBox Plus.app" 2>/dev/null || true
echo "✓ Installation complete!"
echo "Launching moviehub.stream..."
open "/Applications/MovieBox Plus.app"
exit 0
