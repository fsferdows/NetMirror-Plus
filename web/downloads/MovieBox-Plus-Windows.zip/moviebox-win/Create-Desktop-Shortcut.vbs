Set oWS = WScript.CreateObject("WScript.Shell")
sLinkFile = oWS.SpecialFolders("Desktop") & "\MovieBox Plus.lnk"
Set oLink = oWS.CreateShortcut(sLinkFile)
oLink.TargetPath = "msedge.exe"
oLink.Arguments = "--app=https://netmirror-plus.vercel.app/?source=desktop-win"
oLink.Description = "MovieBox Plus - Watch Movies, TV Series & Live Sports in 4K"
oLink.Save
WScript.Echo "MovieBox Plus desktop shortcut created successfully!"
