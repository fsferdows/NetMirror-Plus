MovieBox Plus for Windows
=========================
1. Double-click "Launch-MovieBox-Plus.bat" to start streaming in standalone cinema window.
2. Double-click "Create-Desktop-Shortcut.vbs" to pin MovieBox Plus directly to your Windows Desktop.
