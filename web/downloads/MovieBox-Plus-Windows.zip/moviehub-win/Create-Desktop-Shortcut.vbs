Set oWS = WScript.CreateObject("WScript.Shell")
sLinkFile = oWS.SpecialFolders("Desktop") & "\moviehub.stream.lnk"
Set oLink = oWS.CreateShortcut(sLinkFile)
oLink.TargetPath = "msedge.exe"
oLink.Arguments = "--app=https://moviehub.stream/?source=desktop-win"
oLink.Description = "moviehub.stream - Watch Movies, TV Series & Live Sports in 4K"
oLink.Save
WScript.Echo "moviehub.stream desktop shortcut created successfully!"
