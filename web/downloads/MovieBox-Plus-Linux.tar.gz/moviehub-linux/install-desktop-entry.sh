#!/usr/bin/env bash
mkdir -p ~/.local/share/applications
cp moviehub-stream.desktop ~/.local/share/applications/
echo "moviehub.stream added to application launcher menu!"
