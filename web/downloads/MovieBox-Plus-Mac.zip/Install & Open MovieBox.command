#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
echo "=============================================="
echo " Installing MovieBox Plus to /Applications..."
echo "=============================================="
cp -R "$DIR/MovieBox Plus.app" /Applications/
xattr -cr "/Applications/MovieBox Plus.app"
codesign --force --deep --sign - "/Applications/MovieBox Plus.app" 2>/dev/null || true
echo "✓ Installation complete!"
echo "Launching MovieBox Plus..."
open "/Applications/MovieBox Plus.app"
exit 0
