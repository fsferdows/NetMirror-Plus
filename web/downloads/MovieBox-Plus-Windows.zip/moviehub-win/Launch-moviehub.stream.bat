@echo off
title moviehub.stream - Cinema 4K Streaming
echo Starting moviehub.stream...
start msedge.exe --app=https://moviehub.stream/?source=desktop-win 2>nul || start chrome.exe --app=https://moviehub.stream/?source=desktop-win 2>nul || start https://moviehub.stream/?source=desktop-win
