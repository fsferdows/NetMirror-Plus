#!/usr/bin/env bash
mkdir -p ~/.local/share/applications
cp moviebox-plus.desktop ~/.local/share/applications/
echo "MovieBox Plus added to application launcher menu!"
